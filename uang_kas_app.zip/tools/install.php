<?php
// tools/install.php — buat admin default + kategori default jika belum ada
require_once __DIR__.'/../config/db.php';

$exists = $mysqli->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
if ((int)$exists === 0) {
  $pass = password_hash('admin123', PASSWORD_BCRYPT);
  $stmt = $mysqli->prepare('INSERT INTO users(nama,username,email,password,role) VALUES (?,?,?,?,?)');
  $role='admin';
  $stmt->bind_param('sssss', $n,$u,$e,$p,$r);
  $n='Administrator'; $u='admin'; $e='admin@example.com'; $p=$pass; $r=$role;
  $stmt->execute();
  echo "Admin default dibuat: admin / admin123\n";
}
$cekKat = $mysqli->query("SELECT COUNT(*) c FROM kategori")->fetch_assoc()['c'];
if ((int)$cekKat === 0) {
  $mysqli->query("INSERT INTO kategori(nama,tipe) VALUES ('Iuran Bulanan','masuk'),('Donasi','masuk'),('Operasional','keluar'),('Pembelian','keluar')");
  echo "Kategori default ditambahkan.\n";
}
echo "Selesai.";
