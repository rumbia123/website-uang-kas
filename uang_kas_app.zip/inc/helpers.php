<?php
// inc/helpers.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function is_logged_in() { return isset($_SESSION['user']); }
function user() { return $_SESSION['user'] ?? null; }
function require_login() {
    if (!is_logged_in()) {
        header('Location: /auth/login.php');
        exit;
    }
}
function require_role($roles = []) {
    if (!is_logged_in() || !in_array($_SESSION['user']['role'], $roles)) {
        http_response_code(403);
        echo '<h2>Akses ditolak</h2>';
        exit;
    }
}
function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function rupiah($n){ return number_format($n,0,',','.'); }
?>
