<?php
// inc/header.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Uang Kas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f7f8fb; }
    .navbar-brand { font-weight: 700; letter-spacing:.3px; }
    .card { border:0; box-shadow: 0 6px 18px rgba(0,0,0,.06); border-radius:1rem; }
    .table thead th { background:#f1f3f8; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-white border-bottom sticky-top">
  <div class="container">
    <a class="navbar-brand" href="/index.php">💰 Uang Kas</a>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="/anggota/index.php">Anggota</a></li>
        <li class="nav-item"><a class="nav-link" href="/transaksi/index.php">Transaksi</a></li>
        <li class="nav-item"><a class="nav-link" href="/iuran/index.php">Iuran</a></li>
        <li class="nav-item"><a class="nav-link" href="/laporan/index.php">Laporan</a></li>
      </ul>
      <ul class="navbar-nav ms-auto">
        <?php if(isset($_SESSION['user'])): ?>
          <li class="nav-item"><span class="nav-link">Halo, <?= e($_SESSION['user']['nama']) ?> (<?= e($_SESSION['user']['role']) ?>)</span></li>
          <li class="nav-item"><a class="btn btn-outline-danger btn-sm" href="/auth/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="btn btn-primary btn-sm" href="/auth/login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container my-4">
