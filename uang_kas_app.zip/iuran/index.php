<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$periode = $_GET['periode'] ?? date('Y-m-01');
$stmt=$mysqli->prepare('SELECT i.id, u.nama, i.periode, i.nominal, i.status, i.dibayar_pada FROM iuran i JOIN anggota a ON a.id=i.anggota_id JOIN users u ON u.id=a.user_id WHERE i.periode=? ORDER BY u.nama');
$stmt->bind_param('s',$periode);
$stmt->execute(); $rows=$stmt->get_result();

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Iuran Bulanan</h5>
    <div>
      <a class="btn btn-outline-secondary" href="generate.php">Generate Periode</a>
    </div>
  </div>
  <form class="row g-2 mb-3">
    <div class="col-auto"><label class="col-form-label">Periode</label></div>
    <div class="col-auto"><input type="month" class="form-control" name="periode" value="<?= date('Y-m', strtotime($periode)) ?>"></div>
    <div class="col-auto"><button class="btn btn-primary">Terapkan</button></div>
  </form>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead><tr><th>#</th><th>Nama</th><th>Periode</th><th>Nominal</th><th>Status</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php $no=1; while($r=$rows->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= e($r['nama']) ?></td>
        <td><?= date('F Y', strtotime($r['periode'])) ?></td>
        <td>Rp <?= rupiah($r['nominal']) ?></td>
        <td>
          <span class="badge <?= $r['status']=='LUNAS'?'bg-success':($r['status']=='TUNDA'?'bg-warning':'bg-secondary') ?>"><?= e($r['status']) ?></span>
        </td>
        <td>
          <a class="btn btn-sm btn-success" href="pay.php?id=<?= $r['id'] ?>">Tandai Lunas</a>
          <a class="btn btn-sm btn-warning" href="hold.php?id=<?= $r['id'] ?>">Tunda</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
  </div>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
