<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);
$id=(int)($_GET['id'] ?? 0);
$mysqli->query("UPDATE iuran SET status='TUNDA' WHERE id={$id} LIMIT 1");
header('Location: /iuran/index.php');
