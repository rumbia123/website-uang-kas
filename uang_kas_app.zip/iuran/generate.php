<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$periode = date('Y-m-01');
$nominal_default = 50000;

if($_SERVER['REQUEST_METHOD']==='POST'){
  $periode = $_POST['periode'].'-01';
  $nominal_default = (int)$_POST['nominal'];
  // generate untuk semua anggota
  $anggota = $mysqli->query('SELECT id FROM anggota');
  while($a=$anggota->fetch_assoc()){
    $stmt=$mysqli->prepare('INSERT IGNORE INTO iuran(anggota_id,periode,nominal,status) VALUES(?,?,?,"BELUM")');
    $stmt->bind_param('isd',$a['id'],$periode,$nominal_default);
    $stmt->execute();
  }
  header('Location: /iuran/index.php?periode='.$periode); exit;
}

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <h5>Generate Iuran Bulanan</h5>
  <form method="post" class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Periode</label>
      <input type="month" class="form-control" name="periode" value="<?= date('Y-m') ?>" required>
    </div>
    <div class="col-md-4">
      <label class="form-label">Nominal per Anggota</label>
      <input type="number" class="form-control" name="nominal" min="0" step="1000" value="<?= $nominal_default ?>" required>
    </div>
    <div class="col-12">
      <button class="btn btn-primary">Generate</button>
      <a class="btn btn-light" href="/iuran/index.php">Batal</a>
    </div>
  </form>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
