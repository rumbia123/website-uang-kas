<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-t');

$stmt=$mysqli->prepare("SELECT t.tanggal,t.tipe,k.nama kategori,t.deskripsi,t.nominal FROM transaksi t LEFT JOIN kategori k ON k.id=t.kategori_id WHERE t.tanggal BETWEEN ? AND ? ORDER BY t.tanggal");
$stmt->bind_param('ss',$dari,$sampai);
$stmt->execute();
$rows=$stmt->get_result();

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <h5 class="mb-3">Laporan Transaksi</h5>
  <form class="row g-2 mb-3">
    <div class="col-auto"><label class="col-form-label">Dari</label></div>
    <div class="col-auto"><input type="date" class="form-control" name="dari" value="<?= e($dari) ?>"></div>
    <div class="col-auto"><label class="col-form-label">Sampai</label></div>
    <div class="col-auto"><input type="date" class="form-control" name="sampai" value="<?= e($sampai) ?>"></div>
    <div class="col-auto"><button class="btn btn-primary">Terapkan</button></div>
    <div class="col-auto"><a class="btn btn-outline-secondary" href="export_csv.php?dari=<?= e($dari) ?>&sampai=<?= e($sampai) ?>">Export CSV</a></div>
  </form>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead><tr><th>Tanggal</th><th>Tipe</th><th>Kategori</th><th>Deskripsi</th><th>Nominal</th></tr></thead>
    <tbody>
      <?php $total=0; while($r=$rows->fetch_assoc()): $total += $r['tipe']=='masuk' ? $r['nominal'] : -$r['nominal']; ?>
      <tr>
        <td><?= e($r['tanggal']) ?></td>
        <td><?= e($r['tipe']) ?></td>
        <td><?= e($r['kategori']) ?></td>
        <td><?= e($r['deskripsi']) ?></td>
        <td>Rp <?= rupiah($r['nominal']) ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  </div>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
