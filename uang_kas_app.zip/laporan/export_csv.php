<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);
$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-t');

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=laporan_' . $dari . '_to_' . $sampai . '.csv');
$out = fopen('php://output', 'w');
fputcsv($out, ['Tanggal','Tipe','Kategori','Deskripsi','Nominal']);

$stmt=$mysqli->prepare("SELECT t.tanggal,t.tipe,k.nama kategori,t.deskripsi,t.nominal FROM transaksi t LEFT JOIN kategori k ON k.id=t.kategori_id WHERE t.tanggal BETWEEN ? AND ? ORDER BY t.tanggal");
$stmt->bind_param('ss',$dari,$sampai);
$stmt->execute();
$res=$stmt->get_result();
while($r=$res->fetch_assoc()){
  fputcsv($out, [$r['tanggal'],$r['tipe'],$r['kategori'],$r['deskripsi'],$r['nominal']]);
}
fclose($out);
exit;
