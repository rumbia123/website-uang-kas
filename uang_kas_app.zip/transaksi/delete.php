<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$id=(int)($_GET['id'] ?? 0);
$stmt=$mysqli->prepare('DELETE FROM transaksi WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute();
header('Location: /transaksi/index.php');
