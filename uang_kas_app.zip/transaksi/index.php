<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$rows = $mysqli->query("SELECT t.*, k.nama AS kategori FROM transaksi t LEFT JOIN kategori k ON k.id=t.kategori_id ORDER BY t.tanggal DESC, t.id DESC");

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Transaksi</h5>
    <div class="d-flex gap-2">
      <a class="btn btn-outline-primary" href="create.php?tipe=masuk">+ Kas Masuk</a>
      <a class="btn btn-outline-danger" href="create.php?tipe=keluar">+ Kas Keluar</a>
    </div>
  </div>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead><tr><th>#</th><th>Tanggal</th><th>Tipe</th><th>Kategori</th><th>Deskripsi</th><th>Nominal</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php $no=1; while($r=$rows->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= e($r['tanggal']) ?></td>
        <td><span class="badge <?= $r['tipe']=='masuk'?'bg-success':'bg-danger' ?>"><?= e($r['tipe']) ?></span></td>
        <td><?= e($r['kategori'] ?? '-') ?></td>
        <td><?= e($r['deskripsi']) ?></td>
        <td>Rp <?= rupiah($r['nominal']) ?></td>
        <td>
          <a class="btn btn-sm btn-outline-secondary" href="edit.php?id=<?= $r['id'] ?>">Edit</a>
          <a class="btn btn-sm btn-outline-danger" href="delete.php?id=<?= $r['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  </div>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
