<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$id=(int)($_GET['id'] ?? 0);
$q=$mysqli->prepare('SELECT * FROM transaksi WHERE id=?'); $q->bind_param('i',$id); $q->execute();
$trx=$q->get_result()->fetch_assoc();
if(!$trx){ echo 'Data tidak ditemukan'; exit; }

$kategori = $mysqli->query("SELECT id,nama FROM kategori WHERE tipe='{$trx['tipe']}' ORDER BY nama");

if($_SERVER['REQUEST_METHOD']==='POST'){
  $tanggal=$_POST['tanggal']; $kategori_id=$_POST['kategori_id'] ?: null; $deskripsi=$_POST['deskripsi']; $nominal=(float)$_POST['nominal'];
  $stmt=$mysqli->prepare('UPDATE transaksi SET tanggal=?, kategori_id=?, deskripsi=?, nominal=? WHERE id=?');
  $stmt->bind_param('sissi',$tanggal,$kategori_id,$deskripsi,$nominal,$id);
  $stmt->execute();
  header('Location: /transaksi/index.php'); exit;
}

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <h5>Edit Transaksi</h5>
  <form method="post">
    <div class="row g-3">
      <div class="col-md-3"><label class="form-label">Tanggal</label><input type="date" class="form-control" name="tanggal" value="<?= e($trx['tanggal']) ?>" required></div>
      <div class="col-md-3"><label class="form-label">Kategori</label>
        <select class="form-select" name="kategori_id">
          <option value="">-</option>
          <?php while($k=$kategori->fetch_assoc()): ?>
            <option value="<?= $k['id'] ?>" <?= $trx['kategori_id']==$k['id']?'selected':'' ?>><?= e($k['nama']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-6"><label class="form-label">Deskripsi</label><input class="form-control" name="deskripsi" value="<?= e($trx['deskripsi']) ?>" required></div>
      <div class="col-md-4"><label class="form-label">Nominal</label><input class="form-control" type="number" name="nominal" min="0" step="100" value="<?= e($trx['nominal']) ?>" required></div>
    </div>
    <div class="mt-3 d-flex gap-2">
      <button class="btn btn-primary">Simpan Perubahan</button>
      <a href="/transaksi/index.php" class="btn btn-light">Kembali</a>
    </div>
  </form>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
