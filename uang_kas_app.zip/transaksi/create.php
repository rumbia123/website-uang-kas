<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$tipe = $_GET['tipe'] ?? 'masuk';
if(!in_array($tipe,['masuk','keluar'])) $tipe='masuk';

$kategori = $mysqli->query("SELECT id,nama FROM kategori WHERE tipe='{$tipe}' ORDER BY nama");

if($_SERVER['REQUEST_METHOD']==='POST'){
  $tanggal=$_POST['tanggal']; $tipe=$_POST['tipe']; $kategori_id=$_POST['kategori_id'] ?: null;
  $deskripsi=$_POST['deskripsi']; $nominal=(float)$_POST['nominal']; $uid=user()['id'];
  $stmt=$mysqli->prepare('INSERT INTO transaksi(tanggal,tipe,kategori_id,deskripsi,nominal,dibuat_oleh) VALUES(?,?,?,?,?,?)');
  $stmt->bind_param('ssisss',$tanggal,$tipe,$kategori_id,$deskripsi,$nominal,$uid);
  $stmt->execute();
  header('Location: /transaksi/index.php'); exit;
}

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <h5>Tambah Transaksi <?= e(ucfirst($tipe)) ?></h5>
  <form method="post">
    <input type="hidden" name="tipe" value="<?= e($tipe) ?>">
    <div class="row g-3">
      <div class="col-md-3"><label class="form-label">Tanggal</label><input type="date" class="form-control" name="tanggal" value="<?= date('Y-m-d') ?>" required></div>
      <div class="col-md-3"><label class="form-label">Kategori</label>
        <select class="form-select" name="kategori_id">
          <option value="">-</option>
          <?php while($k=$kategori->fetch_assoc()): ?>
            <option value="<?= $k['id'] ?>"><?= e($k['nama']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-6"><label class="form-label">Deskripsi</label><input class="form-control" name="deskripsi" required></div>
      <div class="col-md-4"><label class="form-label">Nominal</label><input class="form-control" type="number" name="nominal" min="0" step="100" required></div>
    </div>
    <div class="mt-3 d-flex gap-2">
      <button class="btn btn-primary">Simpan</button>
      <a href="/transaksi/index.php" class="btn btn-light">Batal</a>
    </div>
  </form>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
