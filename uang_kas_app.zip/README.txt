UANG KAS – PHP + MySQL (tanpa framework)

Cara menjalankan (XAMPP):
1) Buat database dan tabel:
   - Import file: database.sql di phpMyAdmin (Pastikan kolasi utf8_general_ci).
   - Jalankan sekali: http://localhost/uang_kas_app/tools/install.php  (membuat admin + kategori).
2) Copy folder `uang_kas_app` ke htdocs (atau gunakan path yang sesuai).
3) Buka: http://localhost/uang_kas_app/auth/login.php
   - Login awal: admin / admin123

Peran:
- admin & bendahara: akses penuh (anggota, transaksi, iuran, laporan).
- anggota: login hanya untuk profil (dapat dikembangkan).

Keamanan:
- Prepared statements, session-based auth, role guard dasar.

Catatan:
- Desain menggunakan Bootstrap 5 (CDN).
- File konfigurasi DB: config/db.php