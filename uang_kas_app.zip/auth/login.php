<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';

if (is_logged_in()) { header('Location: /index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $mysqli->prepare('SELECT id,nama,username,email,password,role,aktif FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $res = $stmt->get_result();
    $u = $res->fetch_assoc();
    if ($u && password_verify($password, $u['password'])) {
        if ((int)$u['aktif'] !== 1) {
            $error = 'Akun non-aktif';
        } else {
            $_SESSION['user'] = ['id'=>$u['id'], 'nama'=>$u['nama'], 'username'=>$u['username'], 'role'=>$u['role']];
            header('Location: /index.php');
            exit;
        }
    } else {
        $error = 'Username atau password salah';
    }
}
include __DIR__.'/../inc/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-5">
    <div class="card p-4">
      <h4 class="mb-3">Login</h4>
      <?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
      <form method="post">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" class="form-control" name="username" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <button class="btn btn-primary w-100">Masuk</button>
      </form>
      <p class="text-muted mt-3 mb-0">User awal: admin/admin123 (akan dibuat otomatis saat pertama kali).</p>
    </div>
  </div>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
