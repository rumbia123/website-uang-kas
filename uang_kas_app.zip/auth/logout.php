<?php
require_once __DIR__.'/../inc/helpers.php';
session_destroy();
header('Location: /auth/login.php');
