<?php
require_once __DIR__.'/config/db.php';
require_once __DIR__.'/inc/helpers.php';
require_login();

// ambil saldo
$saldo = 0;
$q = $mysqli->query("SELECT (SELECT IFNULL(SUM(nominal),0) FROM transaksi WHERE tipe='masuk') - (SELECT IFNULL(SUM(nominal),0) FROM transaksi WHERE tipe='keluar') AS saldo");
if ($row = $q->fetch_assoc()) $saldo = (float)$row['saldo'];

// ringkasan transaksi
$summary = ['masuk'=>0,'keluar'=>0];
$q2 = $mysqli->query("SELECT tipe, IFNULL(SUM(nominal),0) total FROM transaksi GROUP BY tipe");
while($r=$q2->fetch_assoc()){ $summary[$r['tipe']] = $r['total']; }

include __DIR__.'/inc/header.php';
?>
<div class="row g-3">
  <div class="col-md-4">
    <div class="card p-4">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <small class="text-muted">Saldo</small>
          <h3 class="mb-0">Rp <?= rupiah($saldo) ?></h3>
        </div>
        <span class="badge bg-success">Realtime</span>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card p-4">
      <small class="text-muted">Total Masuk</small>
      <h4 class="mb-0">Rp <?= rupiah($summary['masuk']) ?></h4>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card p-4">
      <small class="text-muted">Total Keluar</small>
      <h4 class="mb-0">Rp <?= rupiah($summary['keluar']) ?></h4>
    </div>
  </div>
</div>

<div class="card p-4 mt-3">
  <h5>Menu Cepat</h5>
  <div class="d-flex gap-2 flex-wrap">
    <a class="btn btn-outline-primary" href="/transaksi/create.php?tipe=masuk">+ Kas Masuk</a>
    <a class="btn btn-outline-danger" href="/transaksi/create.php?tipe=keluar">+ Kas Keluar</a>
    <a class="btn btn-outline-secondary" href="/iuran/generate.php">Generate Iuran Bulanan</a>
    <a class="btn btn-outline-success" href="/laporan/index.php">Laporan</a>
  </div>
</div>
<?php include __DIR__.'/inc/footer.php'; ?>
