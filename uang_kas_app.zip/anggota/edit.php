<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$id=(int)($_GET['id'] ?? 0);
$q=$mysqli->prepare('SELECT a.id,a.nim_nip,a.hp,u.nama,u.username,u.email FROM anggota a JOIN users u ON u.id=a.user_id WHERE a.id=?');
$q->bind_param('i',$id); $q->execute(); $data=$q->get_result()->fetch_assoc();
if(!$data){ http_response_code(404); echo 'Data tidak ditemukan'; exit; }

$success=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $nama=$_POST['nama']; $email=$_POST['email']; $hp=$_POST['hp']; $nim=$_POST['nim_nip'];
  $stmt=$mysqli->prepare('UPDATE users u JOIN anggota a ON a.user_id=u.id SET u.nama=?, u.email=?, a.hp=?, a.nim_nip=? WHERE a.id=?');
  $stmt->bind_param('ssssi',$nama,$email,$hp,$nim,$id);
  if($stmt->execute()) $success='Perubahan disimpan.'; else $err='Gagal menyimpan perubahan.';
}

include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <h5>Edit Anggota</h5>
  <?php if($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label">Nama</label><input class="form-control" name="nama" value="<?= e($data['nama']) ?>" required></div>
      <div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" name="email" value="<?= e($data['email']) ?>" required></div>
      <div class="col-md-6"><label class="form-label">HP</label><input class="form-control" name="hp" value="<?= e($data['hp']) ?>"></div>
      <div class="col-md-6"><label class="form-label">NIM/NIP</label><input class="form-control" name="nim_nip" value="<?= e($data['nim_nip']) ?>"></div>
    </div>
    <div class="mt-3 d-flex gap-2">
      <button class="btn btn-primary">Simpan Perubahan</button>
      <a href="/anggota/index.php" class="btn btn-light">Kembali</a>
    </div>
  </form>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
