<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$id=(int)($_GET['id'] ?? 0);
$stmt=$mysqli->prepare('SELECT user_id FROM anggota WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if($user){
  $del=$mysqli->prepare('DELETE FROM users WHERE id=?'); $del->bind_param('i',$user['user_id']); $del->execute();
}
header('Location: /anggota/index.php');
