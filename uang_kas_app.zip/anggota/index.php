<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$rows = $mysqli->query("SELECT a.id, u.nama, u.username, u.email, a.nim_nip, a.hp FROM anggota a JOIN users u ON u.id=a.user_id ORDER BY u.nama ASC");
include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Daftar Anggota</h5>
    <a class="btn btn-primary" href="create.php">+ Tambah Anggota</a>
  </div>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead><tr><th>#</th><th>Nama</th><th>Username</th><th>Email</th><th>HP</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php $no=1; while($r=$rows->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= e($r['nama']) ?></td>
        <td><?= e($r['username']) ?></td>
        <td><?= e($r['email']) ?></td>
        <td><?= e($r['hp']) ?></td>
        <td>
          <a class="btn btn-sm btn-outline-secondary" href="edit.php?id=<?= $r['id'] ?>">Edit</a>
          <a class="btn btn-sm btn-outline-danger" href="delete.php?id=<?= $r['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  </div>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
