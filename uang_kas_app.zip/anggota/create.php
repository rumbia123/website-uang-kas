<?php
require_once __DIR__.'/../config/db.php';
require_once __DIR__.'/../inc/helpers.php';
require_login();
require_role(['admin','bendahara']);

$err=''; 
if($_SERVER['REQUEST_METHOD']==='POST'){
  $nama=$_POST['nama']; $username=$_POST['username']; $email=$_POST['email']; $hp=$_POST['hp']; $nim=$_POST['nim_nip'];
  $passHash = password_hash('anggota123', PASSWORD_BCRYPT);
  $role='anggota';
  $stmt=$mysqli->prepare('INSERT INTO users(nama,username,email,password,role) VALUES(?,?,?,?,?)');
  $stmt->bind_param('sssss',$nama,$username,$email,$passHash,$role);
  if($stmt->execute()){
    $uid=$stmt->insert_id;
    $stmt2=$mysqli->prepare('INSERT INTO anggota(user_id,nim_nip,hp) VALUES(?,?,?)');
    $stmt2->bind_param('iss',$uid,$nim,$hp);
    $stmt2->execute();
    header('Location: /anggota/index.php'); exit;
  }else{
    $err='Gagal simpan. Pastikan username/email unik.';
  }
}
include __DIR__.'/../inc/header.php';
?>
<div class="card p-4">
  <h5>Tambah Anggota</h5>
  <?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <form method="post">
    <div class="row g-3">
      <div class="col-md-6"><label class="form-label">Nama</label><input class="form-control" name="nama" required></div>
      <div class="col-md-3"><label class="form-label">Username</label><input class="form-control" name="username" required></div>
      <div class="col-md-3"><label class="form-label">HP</label><input class="form-control" name="hp"></div>
      <div class="col-md-6"><label class="form-label">Email</label><input type="email" class="form-control" name="email" required></div>
      <div class="col-md-6"><label class="form-label">NIM/NIP</label><input class="form-control" name="nim_nip"></div>
    </div>
    <div class="mt-3 d-flex gap-2">
      <button class="btn btn-primary">Simpan</button>
      <a href="/anggota/index.php" class="btn btn-light">Batal</a>
    </div>
    <p class="text-muted mt-2 mb-0">Password default anggota: <b>anggota123</b> (dapat diganti oleh anggota setelah login).</p>
  </form>
</div>
<?php include __DIR__.'/../inc/footer.php'; ?>
