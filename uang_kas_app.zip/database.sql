-- UANG KAS APP – MySQL 5.7 compatible
CREATE DATABASE IF NOT EXISTS uang_kas CHARACTER SET utf8 COLLATE utf8_general_ci;
USE uang_kas;

-- USERS (admin, bendahara, anggota)
CREATE TABLE IF NOT EXISTS users (
  id INT NOT NULL AUTO_INCREMENT,
  nama VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','bendahara','anggota') NOT NULL DEFAULT 'anggota',
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ANGGOTA (profil ringkas, optional extended)
CREATE TABLE IF NOT EXISTS anggota (
  id INT NOT NULL AUTO_INCREMENT,
  user_id INT NOT NULL,
  nim_nip VARCHAR(50) NULL,
  alamat VARCHAR(255) NULL,
  hp VARCHAR(30) NULL,
  PRIMARY KEY (id),
  KEY idx_user (user_id),
  CONSTRAINT fk_anggota_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- KATEGORI TRANSAKSI
CREATE TABLE IF NOT EXISTS kategori (
  id INT NOT NULL AUTO_INCREMENT,
  nama VARCHAR(100) NOT NULL,
  tipe ENUM('masuk','keluar') NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_kategori (nama, tipe)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- TRANSAKSI UMUM (kas_masuk & kas_keluar)
CREATE TABLE IF NOT EXISTS transaksi (
  id INT NOT NULL AUTO_INCREMENT,
  tanggal DATE NOT NULL,
  tipe ENUM('masuk','keluar') NOT NULL,
  kategori_id INT NULL,
  deskripsi VARCHAR(255) NOT NULL,
  nominal DECIMAL(14,2) NOT NULL,
  dibuat_oleh INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_kategori (kategori_id),
  KEY idx_pembuat (dibuat_oleh),
  CONSTRAINT fk_trans_kategori FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE SET NULL,
  CONSTRAINT fk_trans_user FOREIGN KEY (dibuat_oleh) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- IURAN BULANAN PER ANGGOTA
CREATE TABLE IF NOT EXISTS iuran (
  id INT NOT NULL AUTO_INCREMENT,
  anggota_id INT NOT NULL,
  periode DATE NOT NULL, -- gunakan tanggal 1 setiap bulan (YYYY-MM-01)
  nominal DECIMAL(14,2) NOT NULL,
  status ENUM('BELUM','LUNAS','TUNDA') NOT NULL DEFAULT 'BELUM',
  dibayar_pada DATETIME NULL,
  catatan VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_periode (anggota_id, periode),
  KEY idx_anggota (anggota_id),
  CONSTRAINT fk_iuran_anggota FOREIGN KEY (anggota_id) REFERENCES anggota(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- VIEW SALDO
DROP VIEW IF EXISTS vw_saldo;
CREATE VIEW vw_saldo AS
  SELECT
    (SELECT IFNULL(SUM(nominal),0) FROM transaksi WHERE tipe='masuk') 
    - (SELECT IFNULL(SUM(nominal),0) FROM transaksi WHERE tipe='keluar') AS saldo;